// JavaScript File

// Card object constructor
function Card(suit, value) {
    this.suit = suit;
    this.value = value;
}

// Global card object
let drawnCard = null;

// Function to draw a random card
function drawCard() {
    const suits = ["Club", "Diamond", "Heart", "Spade"];
    const values = Array.from({ length: 13 }, (_, i) => i + 1);

    const randomSuit = suits[Math.floor(Math.random() * suits.length)];
    const randomValue = values[Math.floor(Math.random() * values.length)];

    drawnCard = new Card(randomSuit, randomValue);
    console.log(`Drawn Card: ${drawnCard.suit} ${drawnCard.value}`); // For debugging
}

// Function to check the user's guess
function checkGuess() {
    const selectedValue = parseInt(document.getElementById("cardValue").value);
    const selectedSuit = document.getElementById("cardSuit").value;

    const message = document.getElementById("message");

    if (drawnCard && selectedValue === drawnCard.value && selectedSuit === drawnCard.suit) {
        message.textContent = "You got it!";
    } else {
        message.textContent = "Better Luck Next Time!";
    }
}
